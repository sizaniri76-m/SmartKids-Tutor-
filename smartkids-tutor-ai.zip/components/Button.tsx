import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  fullWidth = false,
  className = '',
  ...props 
}) => {
  const baseStyles = "rounded-2xl font-bold transition-all transform active:scale-95 shadow-md flex items-center justify-center gap-2";
  
  const variants = {
    primary: "bg-indigo-500 text-white hover:bg-indigo-600 shadow-indigo-200 dark:shadow-none dark:bg-indigo-600 dark:hover:bg-indigo-500",
    secondary: "bg-white text-gray-700 hover:bg-gray-50 border-2 border-gray-100 dark:bg-stone-800 dark:text-stone-200 dark:border-stone-700 dark:hover:bg-stone-700",
    danger: "bg-red-500 text-white hover:bg-red-600 shadow-red-200 dark:shadow-none dark:bg-red-600",
    ghost: "bg-transparent text-gray-600 hover:bg-gray-100 shadow-none dark:text-stone-300 dark:hover:bg-stone-800"
  };

  const sizes = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-5 py-3 text-base",
    lg: "px-8 py-4 text-lg",
    xl: "px-10 py-5 text-xl"
  };

  const widthClass = fullWidth ? "w-full" : "";

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${widthClass} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};