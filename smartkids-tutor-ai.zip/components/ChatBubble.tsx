
import React, { useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage, Language, VoicePreference } from '../types';
import { Volume2 } from 'lucide-react';
import { speechService } from '../services/speechService';

interface ChatBubbleProps {
  message: ChatMessage;
  language: Language;
  voicePreference?: VoicePreference;
  speakingRate?: number;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message, language, voicePreference, speakingRate = 0.8 }) => {
  const isUser = message.role === 'user';
  const hasSpoken = useRef<boolean>(false);

  // Auto-speak tutor messages when they arrive
  useEffect(() => {
    if (!isUser && message.text && !message.isError && !hasSpoken.current) {
      const timer = setTimeout(() => {
        speechService.speak(message.text, language, voicePreference, speakingRate);
        hasSpoken.current = true;
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [message.id, voicePreference, speakingRate, isUser]); 

  return (
    <div className={`flex w-full ${isUser ? 'justify-start' : 'justify-end'} mb-4 animate-fade-in-up`}>
      <div 
        className={`
          max-w-[85%] rounded-3xl p-4 relative group
          ${isUser 
            ? 'bg-amber-100 text-amber-900 rounded-br-none dark:bg-amber-900 dark:text-amber-100 shadow-sm' 
            : 'bg-white text-gray-800 shadow-md border border-indigo-50 rounded-bl-none dark:bg-stone-800 dark:text-stone-100 dark:border-stone-700'}
        `}
      >
        <div className="prose prose-sm max-w-none prose-p:my-1 prose-headings:my-2 dark:prose-invert">
          <ReactMarkdown>{message.text}</ReactMarkdown>
        </div>
        
        {!isUser && (
           <button 
             onClick={() => speechService.speak(message.text, language, voicePreference, speakingRate)}
             className="absolute -bottom-8 end-0 p-2 text-indigo-400 hover:text-indigo-600 transition-colors dark:text-indigo-300 dark:hover:text-indigo-200 opacity-0 group-hover:opacity-100 focus:opacity-100"
             aria-label="Read aloud"
           >
             <Volume2 size={20} />
           </button>
        )}
      </div>
    </div>
  );
};
