
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Language, Subject, UserProfile, ChatMessage, PremiumContentResponse, Difficulty, ResourceLink, ExerciseType } from '../types';

/**
 * Helper to handle API retries with exponential backoff for 500/XHR errors.
 */
async function withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const errorMsg = error?.message || "";
    const isRetryable = errorMsg.includes("500") || errorMsg.includes("xhr error") || error?.status === 500;
    
    if (retries > 0 && isRetryable) {
      console.warn(`Gemini API error detected, retrying in ${delay}ms... (${retries} retries left)`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return withRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

const detectExerciseType = (text: string): ExerciseType => {
  if (text.includes("Je choisis") || text.includes("coche")) return "multiple_choice";
  if (text.includes("Je lis le dialogue")) return "dialogue";
  if (text.includes("Je corrige")) return "sentence_correction";
  return "general";
};

const cleanExtractedText = (text: string): string => {
  return text.replace(/\s+/g, ' ').replace(/[•◦■]/g, '').trim();
};

const getSystemInstruction = (language: Language, subject: Subject | null, profile: UserProfile) => {
    const age = profile.age || 10;
    const pedagogyRulesMap = {
      [Language.ARABIC]: `قواعد التدريس والأسلوب (إلزامية وصارمة جداً):
      1. هيكلية الرد: يجب أن تشرح فكرة واحدة فقط في كل رد.
      2. قاعدة التوقف الإلزامية: بعد كل شرح، يجب أن تتوقف وتسأل سؤالاً واحداً محدداً لاختبار الفهم.
      3. ممنوع الاستمرار التلقائي: لا تنتقل للخطوة التالية إلا بعد أن يجيب الطفل بشكل صحيح.
      4. نبرة الصوت: معلم حقيقي، دافئ، ومشجع.`,
      [Language.ENGLISH]: `Pedagogical and Voice Rules (Mandatory & Strict):
      1. Response Structure: Explain only ONE concept per turn.
      2. Mandatory Pause Rule: After every explanation, you MUST ask ONE specific question to check understanding.
      3. No Auto-Continue: Do NOT proceed until the child answers correctly.
      4. Voice & Style: Speak like a real, warm, and human teacher.`,
      [Language.FRENCH]: `Règles pédagogiques et vocales (Obligatoires et strictes) :
      1. Structure de réponse : Expliquez un SEUL concept par tour.
      2. Règle de pause obligatoire : Après chaque explication, vous DEVEZ poser UNE question spécifique.
      3. Pas de continuation automatique : Ne passez pas à l'étape suivante sans réponse correcte.
      4. Voix et style : Parlez comme un vrai professeur, chaleureux et humain.`
    };

    const subjectName = subject 
      ? (language === Language.ARABIC ? subject.nameAr : (language === Language.FRENCH ? subject.nameFr : subject.nameEn))
      : "General";

    const personaMap = {
      [Language.ARABIC]: `أنت "المعلم الذكي"، المعلم التفاعلي والصبور للطفل ${profile.name}. الموضوع: ${subjectName}`,
      [Language.ENGLISH]: `You are "Smart Tutor", the interactive and patient teacher for ${profile.name}. Subject: ${subjectName}`,
      [Language.FRENCH]: `Tu es "Tuteur Intelligent", le professeur interactif et patient pour ${profile.name}. Sujet : ${subjectName}`
    };

    return `
      ${personaMap[language]}
      ${pedagogyRulesMap[language]}
      Target Age: ${age}. Adjust complexity for grade level accordingly.
      IMPORTANT: Always end your explanation with a clear, direct question about what you just explained.
    `;
};

export const generateTutorResponse = async (
  message: string,
  history: { role: 'user' | 'model'; text: string }[],
  language: Language,
  subject: Subject | null,
  profile: UserProfile
): Promise<string> => {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const systemInstruction = getSystemInstruction(language, subject, profile);
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
      })),
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.8,
      }
    });

    const result: GenerateContentResponse = await chat.sendMessage({ message });
    return result.text || (language === Language.ARABIC ? 'هل فهمت ما قلته يا بطل؟' : 'Did you understand what I said?');
  });
};

export const explainLessonImage = async (
    imageBase64: string,
    bookTitle: string,
    language: Language,
    profile: UserProfile
): Promise<{ explanation: string; recognizedText: string; resources: ResourceLink[]; exerciseType: ExerciseType }> => {
    return withRetry(async () => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const baseSystem = getSystemInstruction(language, null, profile);
        const promptMap = {
            [Language.ARABIC]: `قم باستخراج كافة النصوص من هذه الصورة بدقة (OCR) ثم ابدأ بشرح أول فكرة بأسلوب بسيط للطفل واطرح سؤالاً عنها.`,
            [Language.ENGLISH]: `Extract all text from this image accurately (OCR), then explain the first concept simply and ask a question about it.`,
            [Language.FRENCH]: `Extrais tout le texte de cette image (OCR), puis explique le premier concept et pose une question.`,
        };

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: {
                parts: [
                    { inlineData: { mimeType: 'image/jpeg', data: imageBase64 } },
                    { text: promptMap[language] }
                ]
            },
            config: {
                systemInstruction: baseSystem,
                temperature: 0.3,
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        recognizedText: { type: Type.STRING },
                        explanation: { type: Type.STRING },
                        resources: { 
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    title: { type: Type.STRING },
                                    url: { type: Type.STRING },
                                    source: { type: Type.STRING }
                                }
                            }
                        }
                    },
                    required: ["recognizedText", "explanation"]
                }
            }
        });

        const result = JSON.parse(response.text || "{}");
        return {
            recognizedText: cleanExtractedText(result.recognizedText || ""),
            explanation: result.explanation || "Done.",
            resources: result.resources || [],
            exerciseType: detectExerciseType(result.recognizedText || "")
        };
    });
}

export const generateLessonQuiz = async (
    lastTutorMessage: string,
    profile: UserProfile,
    language: Language
): Promise<PremiumContentResponse> => {
    return withRetry(async () => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `
        The tutor just said: "${lastTutorMessage}"
        Your task:
        1. Identify the specific question the tutor asked at the end of their message.
        2. Create a Multiple Choice Quiz (3 options) based EXACTLY on that question.
        3. One option must be correct, others must be plausible but wrong.
        4. Return as JSON with keys: question, options, answer, explanation.
        Language: ${language === Language.ARABIC ? 'Arabic' : language === Language.FRENCH ? 'French' : 'English'}.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: {
                temperature: 0.4,
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        question: { type: Type.STRING },
                        options: { type: Type.ARRAY, items: { type: Type.STRING } },
                        answer: { type: Type.STRING },
                        explanation: { type: Type.STRING }
                    },
                    required: ["question", "options", "answer", "explanation"]
                }
            }
        });
        return JSON.parse(response.text || "{}") as PremiumContentResponse;
    });
}

export const generateChildReport = async (
    profile: UserProfile,
    recentMessages: ChatMessage[],
    language: Language
): Promise<string> => {
    return withRetry(async () => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const context = recentMessages.slice(-20).map(m => `${m.role}: ${m.text}`).join('\n');
        const prompt = `Generate an educational report for ${profile.name} (Age: ${profile.age}) based on these messages. Focus on progress and strengths. Language: ${language}. Context:\n${context}`;
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: prompt,
            config: { temperature: 0.7 }
        });
        return response.text || "Report failed.";
    });
}

export const generateFamilyReport = async (
    profiles: UserProfile[],
    language: Language
): Promise<string> => {
    return withRetry(async () => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const profilesSummary = profiles.map(p => `- ${p.name} (Age: ${p.age})`).join('\n');
        const prompt = `Generate a unified progress report for a parent with multiple children:\n${profilesSummary}\nFocus on collective learning and family advice. Language: ${language}.`;
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: prompt,
            config: { temperature: 0.7 }
        });
        return response.text || "Report failed.";
    });
}

export const generatePremiumContent = async (
    type: 'game' | 'math' | 'science' | 'language' | 'guess',
    profile: UserProfile,
    language: Language,
    difficulty: Difficulty,
    specificLang?: 'english' | 'french'
): Promise<PremiumContentResponse> => {
    return withRetry(async () => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        let customPrompt = `Create a premium educational challenge of type "${type}" for ${profile.name} (Age: ${profile.age}). Difficulty: ${difficulty}. Language: ${language}.`;
        
        if (type === 'language' && specificLang) {
          customPrompt = `Create a "Identify Object" game in ${specificLang}. 
          The goal is to show a small image of an object (like Apple, Car, Dog) and ask the child "What is this?". 
          Provide 3 options in ${specificLang}. 
          Crucially, return a field "imagePrompt" containing a simple, clear visual description for an image generator (e.g., "A bright red cartoon apple, high quality, white background"). 
          The question and feedback should be in the user's interface language (${language}), but options and answer must be in ${specificLang}.`;
        } else if (type === 'guess') {
          customPrompt += ` Include an "imagePrompt" for a visual hint about the thing being guessed.`;
        }

        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: customPrompt,
            config: {
                temperature: 0.8,
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        question: { type: Type.STRING },
                        options: { type: Type.ARRAY, items: { type: Type.STRING } },
                        answer: { type: Type.STRING },
                        explanation: { type: Type.STRING },
                        difficulty: { type: Type.STRING },
                        imagePrompt: { type: Type.STRING }
                    },
                    required: ["question", "answer", "explanation", "difficulty"]
                }
            }
        });
        return JSON.parse(response.text || "{}") as PremiumContentResponse;
    });
}

export const generateObjectImage = async (prompt: string): Promise<string> => {
  return withRetry(async () => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { text: `Simple educational illustration for kids: ${prompt}. Cartoon style, flat design, white background.` }
        ]
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image generated");
  });
};
