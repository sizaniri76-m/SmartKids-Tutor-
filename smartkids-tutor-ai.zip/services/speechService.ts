
import { GoogleGenAI, Modality } from "@google/genai";
import { Language, VoicePreference } from '../types';

class SpeechService {
  private audioContext: AudioContext | null = null;
  private currentSource: AudioBufferSourceNode | null = null;
  private isProcessing: boolean = false;

  constructor() {}

  private initAudioContext() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    if (this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }
  }

  private decodeBase64(base64: string): Uint8Array {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  private async decodeAudioData(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const numChannels = 1;
    const sampleRate = 24000;
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  /**
   * Helper to handle API retries with exponential backoff for 500/XHR errors.
   * Specifically detects 429 (Quota Exceeded) to trigger local fallback.
   */
  private async withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
    try {
      return await fn();
    } catch (error: any) {
      const errorMsg = error?.message || "";
      const isRetryable = errorMsg.includes("500") || errorMsg.includes("xhr error") || error?.status === 500;
      const isQuotaError = errorMsg.includes("429") || error?.status === 429;
      
      if (isQuotaError) {
        throw new Error("QUOTA_EXCEEDED");
      }

      if (retries > 0 && isRetryable) {
        console.warn(`Speech API error, retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.withRetry(fn, retries - 1, delay * 2);
      }
      throw error;
    }
  }

  /**
   * Fallback using browser's built-in Web Speech API
   */
  private speakNative(text: string, language: Language, voiceType: VoicePreference, rate: number): void {
    if (!window.speechSynthesis) return;
    
    // Stop any existing native speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set language
    const langMap = {
      [Language.ARABIC]: 'ar-SA',
      [Language.ENGLISH]: 'en-US',
      [Language.FRENCH]: 'fr-FR'
    };
    utterance.lang = langMap[language];
    utterance.rate = rate;

    // Try to find a matching voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => 
      v.lang.startsWith(utterance.lang.split('-')[0]) && 
      (voiceType === 'female' ? v.name.toLowerCase().includes('female') : v.name.toLowerCase().includes('male'))
    ) || voices.find(v => v.lang.startsWith(utterance.lang.split('-')[0]));

    if (preferredVoice) utterance.voice = preferredVoice;

    window.speechSynthesis.speak(utterance);
  }

  public async speak(text: string, language: Language, voiceType: VoicePreference = 'female', rate: number = 0.9): Promise<void> {
    if (!text) return;
    
    this.stop(); 
    this.isProcessing = true;

    try {
      this.initAudioContext();
      const voiceName = voiceType === 'female' ? 'Kore' : 'Puck';
      const speedInstruction = rate < 0.8 ? "ببطء شديد" : rate > 1.2 ? "بسرعة" : "بشكل طبيعي";
      const promptPrefix = language === Language.ARABIC 
        ? `اقرأ النص التالي ${speedInstruction} وبصوت دافئ للأطفال: ` 
        : `Read the following text ${rate < 0.8 ? 'slowly' : 'naturally'} with a warm tone for kids: `;

      const response = await this.withRetry(async () => {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        return ai.models.generateContent({
          model: "gemini-2.5-flash-preview-tts",
          contents: [{ parts: [{ text: promptPrefix + text }] }],
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: voiceName },
              },
            },
          },
        });
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio && this.audioContext) {
        this.stop();
        const audioData = this.decodeBase64(base64Audio);
        const audioBuffer = await this.decodeAudioData(audioData, this.audioContext);
        
        const source = this.audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.playbackRate.value = rate; 
        
        source.connect(this.audioContext.destination);
        source.onended = () => { this.isProcessing = false; };
        source.start();
        this.currentSource = source;
      }
    } catch (error: any) {
      if (error.message === "QUOTA_EXCEEDED") {
        console.warn("Gemini TTS Quota exceeded. Using native browser speech synthesis fallback.");
        this.speakNative(text, language, voiceType, rate);
      } else {
        console.error("Speech Service Error:", error);
      }
      this.isProcessing = false;
    }
  }

  public stop(): void {
    if (this.currentSource) {
      try {
        this.currentSource.stop();
        this.currentSource.disconnect();
      } catch (e) {}
      this.currentSource = null;
    }
    // Also stop native speech if active
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    this.isProcessing = false;
  }

  public listen(language: Language, onResult: (text: string) => void, onEnd: () => void): void {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.lang = language === Language.ARABIC ? 'ar-SA' : language === Language.FRENCH ? 'fr-FR' : 'en-US';
    recognition.onresult = (event: any) => onResult(event.results[0][0].transcript);
    recognition.onend = onEnd;
    recognition.start();
  }

  public stopListening(): void {}
}

export const speechService = new SpeechService();
